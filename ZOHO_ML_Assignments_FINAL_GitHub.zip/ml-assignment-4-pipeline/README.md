# ML Assignment 4 — End-to-End Pipeline

Dataset: UCI Online Retail II  
Source: https://archive.ics.uci.edu/dataset/502/online+retail+ii

The notebook:
1. documents the data dictionary,
2. reports raw data-quality issues,
3. implements `load_data()`, `clean(df)`, `add_features(df)`, and `build_pipeline(df)`,
4. creates a clean train/test matrix without training a model, using Revenue only as the held-out target and excluding revenue-derived fields from X,
5. asserts the required output properties,
6. saves `cleaned_online_retail_endtoend.csv` and `pipeline.joblib`.

Run all cells in Colab before submission.
