# Machine Learning Internship — Assignments 1 to 4

This package contains four separate GitHub-ready repositories based directly on the supplied assignment brief.

## Repositories

1. `ml-assignment-1-numpy` — NumPy vectorised computation
2. `ml-assignment-2-pandas` — Pandas messy-data handling
3. `ml-assignment-3-preprocessing` — leakage-safe preprocessing
4. `ml-assignment-4-pipeline` — end-to-end raw-file-to-clean-matrix pipeline

## Dataset decisions

- Assignment 2: UCI Online Retail II — real, public, 1M+ transaction dataset with 8 variables and missing values.
- Assignment 3: UCI Census Income / Adult — 48K+ rows, mixed categorical/integer features, missing values and an imbalanced income target.
- Assignment 4: UCI Online Retail II — raw, mixed-type, missing-value transaction data.

## Important submission step

The assignment requires each notebook to be run in Google Colab with **Runtime → Restart and run all** and every output visible. Runtime-dependent measurements (speed-up, memory saving, file sizes, load times, and dataset-specific counts) are deliberately not fabricated. Run the notebooks first, then commit the generated outputs/files to the corresponding GitHub repository.

## Dataset uniqueness

The brief says no two students in the same batch may use the same Assignment 2 dataset, so confirm the selected dataset is not already used by another student before final submission.
