# ML Assignment 2 — Pandas Messy Data Handling

Dataset: UCI Online Retail II  
Source: https://archive.ics.uci.edu/dataset/502/online+retail+ii

The notebook creates `online_retail_ii_working.csv` from the real UCI workbook, then produces the required cleaned CSV and Parquet files.

After execution, add the generated CSV to the repository if your submission portal requires the exact working file.

## Required README values after running
- Memory saving: **copy from Q1 output**
- CSV size: **copy from Q13 output**
- Parquet size: **copy from Q13 output**
- CSV load time: **copy from Q13 output**
- Parquet load time: **copy from Q13 output**
